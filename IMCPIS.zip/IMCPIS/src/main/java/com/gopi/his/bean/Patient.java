package com.gopi.his.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "PatientTable")
public class Patient {

	@Id
	@GeneratedValue
	@Column
	private Integer patId;
	@Column	
	private String patName;
	@Column
	private int patAge;
	@Column
	private int patMobile;
	@Column
	private String patAddr;
	@Column	
	private String patGardiean;

	public Integer getPatId() {
		return patId;
	}

	public void setPatId(Integer patId) {
		this.patId = patId;
	}

	public String getPatName() {
		return patName;
	}

	public void setPatName(String patName) {
		this.patName = patName;
	}

	public int getPatAge() {
		return patAge;
	}

	public void setPatAge(int patAge) {
		this.patAge = patAge;
	}

	public int getPatMobile() {
		return patMobile;
	}

	public void setPatMobile(int patMobile) {
		this.patMobile = patMobile;
	}

	public String getPatAddr() {
		return patAddr;
	}

	public void setPatAddr(String patAddr) {
		this.patAddr = patAddr;
	}

	public String getPatGardiean() {
		return patGardiean;
	}

	public void setPatGardiean(String patGardiean) {
		this.patGardiean = patGardiean;
	}

	@Override
	public String toString() {
		return "PatientBean [patId=" + patId + ", patName=" + patName + ", patAge=" + patAge + ", patMobile="
				+ patMobile + ", patAddr=" + patAddr + ", patGardiean=" + patGardiean + "]";
	}

}
