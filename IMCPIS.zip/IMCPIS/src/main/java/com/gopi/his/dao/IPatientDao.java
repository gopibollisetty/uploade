package com.gopi.his.dao;

import java.util.List;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;

public interface IPatientDao {

	public int  savePatient(Patient patientBean);
	public void updatePatient(Patient patientBean); 
	public void deletePatient(int patId);
	public Patient getPatientById(int patId);
	public List<Patient> getAllPatients();
	
	public int saveImage(UploadeImage image);
	public List<UploadeImage> getAllImages();
	
	
}

