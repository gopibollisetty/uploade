package com.gopi.his.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;
import com.gopi.his.dao.IPatientDao;

@Service
public class PatientServiceImpl implements IPatientService {

	@Autowired
	private IPatientDao iPatientDao;
	
	@Transactional(readOnly=false)
	
	public int savePatient(Patient patientBean) {
		return iPatientDao.savePatient(patientBean);
	}

	public void updatePatient(Patient patientBean) {

	}

	public void deletePatient(int patId) {

	}

	public Patient getPatientById(int patId) {
		return null;
	}

	public List<Patient> getAllPatients() {
		return iPatientDao.getAllPatients();
	}

	@Transactional(readOnly=false)
	public int saveImage(UploadeImage image) {
		return iPatientDao.saveImage(image);
	}

	public List<UploadeImage> getAllImages() {
		return iPatientDao.getAllImages();
	}

}
