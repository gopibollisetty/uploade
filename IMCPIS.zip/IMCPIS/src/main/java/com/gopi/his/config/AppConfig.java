package com.gopi.his.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;

@Configuration
@ComponentScan(basePackages = "com.gopi")
@EnableWebMvc
@EnableTransactionManagement
public class AppConfig {

	@Bean
	public DataSource getDataSourceObj() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName("com.mysql.jdbc.Driver");
		driverManagerDataSource.setUrl("jdbc:mysql://localhost:3306/test");
		driverManagerDataSource.setUsername("root");
		driverManagerDataSource.setPassword("ratan");
		return driverManagerDataSource;
	}

	@Bean
	public LocalSessionFactoryBean getLocalSessionFactoryObj() {
		LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
		localSessionFactoryBean.setDataSource(getDataSourceObj());
		localSessionFactoryBean.setAnnotatedClasses(Patient.class,UploadeImage.class);
		localSessionFactoryBean.setHibernateProperties(props());
		return localSessionFactoryBean;
	} 

	private Properties props() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.format_sql", "true");
		properties.put("hibernate.hbm2ddl.auto", "update");
		return properties;
	}

	@Bean
	public HibernateTemplate getHibernateTemplateObj() {
		HibernateTemplate hibernateTemplate = new HibernateTemplate();
		hibernateTemplate.setSessionFactory(getLocalSessionFactoryObj().getObject());
		return hibernateTemplate;
	}

	@Bean
	public HibernateTransactionManager getHibernateTransactionManager() {
		HibernateTransactionManager hibernateTransactionManager = new HibernateTransactionManager();
		hibernateTransactionManager.setSessionFactory(getLocalSessionFactoryObj().getObject());
		return hibernateTransactionManager;
	}
}
