package com.gopi.his.service;

import java.util.List;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;

public interface IPatientService {
	
	public int  savePatient(Patient patientBean);
	public void updatePatient(Patient patientBean); 
	public void deletePatient(int patId);
	public Patient getPatientById(int patId);
	public List<Patient> getAllPatients();
	
	public int saveImage(UploadeImage image);
	public List<UploadeImage> getAllImages();

}
