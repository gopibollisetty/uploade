package com.gopi.his.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;

@Repository
public class PatientDaoImpl implements IPatientDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public int savePatient(Patient patientBean) {
		return (Integer) hibernateTemplate.save(patientBean);
	}

	public void updatePatient(Patient patientBean) {

	}

	public void deletePatient(int patId) {

	}

	public Patient getPatientById(int patId) {
		return null;
	}

	public List<Patient> getAllPatients() {
		return hibernateTemplate.loadAll(Patient.class);
	}

	public int saveImage(UploadeImage image) {
	
		
		return (Integer) hibernateTemplate.save(image);
	}

	public List<UploadeImage> getAllImages() {
		return hibernateTemplate.loadAll(UploadeImage.class);
	}

}
