package com.gopi.his.controller;


public @interface GopiController {

}
