package com.gopi.his.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gopi.his.bean.Patient;
import com.gopi.his.bean.UploadeImage;
import com.gopi.his.service.IPatientService;

@RestController
@RequestMapping(value = "/pat")
@CrossOrigin
public class PatientController {

	@Autowired
	private IPatientService iPatientService;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public Integer SavePatient(@RequestBody Patient patientBean) {
		System.out.println("good");
		return iPatientService.savePatient(patientBean);

	}

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public List<Patient> getAllPatients() {
		System.out.println("good");
		return iPatientService.getAllPatients();
	}

	@RequestMapping(value = "/uploade", method = RequestMethod.GET)
	public Integer uploade(@RequestParam("img-data") byte[] data) throws IOException {
		System.out.println("good");
		System.out.println(data);
		String encoded = Base64.getEncoder().encodeToString(data);
		byte[] decoded = Base64.getDecoder().decode(encoded);
		UploadeImage uploadeImage = new UploadeImage();

		uploadeImage.setImage(decoded);

		FileInputStream fis = null;
		fis = new FileInputStream(encoded);
		byte[] arr;
		arr = new byte[fis.available()];
		fis.read(arr);
		uploadeImage.setImage(arr);

		Integer count = iPatientService.saveImage(uploadeImage);
		fis.close();
		return count;
	}

	@RequestMapping(value = "/get-all-images", method = RequestMethod.GET)
	public List<UploadeImage> getAllImages() {
		System.out.println("good");
		return iPatientService.getAllImages();
	}
}