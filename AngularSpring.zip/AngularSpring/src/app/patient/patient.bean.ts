export class PatientBean {
    patId:number
    patName:String
    patAge:number
    patMobile:number
    patAddr:String
    patGardiean:String
}