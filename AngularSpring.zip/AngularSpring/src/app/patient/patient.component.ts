import { Component, OnInit } from '@angular/core';
import { PatientBean } from './patient.bean';
import { PatientService } from '../patient.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
  lsPath: any;

  constructor(private patientService: PatientService, private domSanitizer: DomSanitizer) { }

  ngOnInit() {
  }

  patienBeanRegister: PatientBean = new PatientBean();
  patienBeanLogin = new PatientBean();
  allPatients: PatientBean[] = [];
  imageurl: SafeUrl;
  patientRegister(patienBeanRegister: PatientBean): any {
    alert("gopi-Reg")
    this.patientService.patientRegistration(this.patienBeanRegister).subscribe((data: any) => {
      console.log(data);
    })
  }
  patientLogin(): any {

  }

  patientRetrival() {
    this.patientService.patientRetrival().subscribe(data => {
      this.allPatients = data;
    })
  }

  uploade(fileImport): void {
    fileImport.value = "";
    fileImport.click();
  }

  fileChange(event: any): void {
    if (event && event[0]) {
      this.lsPath = event[0].name;
      const reader = new FileReader();
      reader.onload = rdr => {
        let img = reader.result;
        img = img.toString().replace("data:image/jpeg;base64,", "")
        const binaryString = window.atob(img);
        const binaryLen = binaryString.length;
        const bytes = new Array(binaryLen);
        for (let i = 0; i <= binaryLen; i++) {
          const ascii = binaryString.charCodeAt(i);
          bytes[i] = ascii;
        }
        if (bytes) {
          this.patientService.uploadeData(bytes).subscribe(res => {
            console.log(res);
          })
        }
      }

      reader.readAsDataURL(event[0]);
    }
    else {
      return;
    }
  }

  getAllImages(): void {
    let self = this;
    this.patientService.imageRetrieval().subscribe(data => {
      // const binaryLen = data.length;
      // const bytes = new Array(binaryLen);
      // for (let i = 0; i <= binaryLen; i++) {
      //   const ascii = data.charCodeAt(i);
      //   bytes[i] = ascii;
      // }
      // if (bytes) {

        let bytes = [];

        let utf8 = encodeURIComponent(data);
        for (var i = 0; i < utf8.length; i++) {
            bytes.push(utf8.charCodeAt(i));
        }
        const TYPED_ARRAY = new Uint8Array(bytes);

        const STRING_CHAR = String.fromCharCode.apply(null, TYPED_ARRAY);

        let base64String = btoa(STRING_CHAR);

        //sanitize the url that is passed as a value to image src attrtibute
        self.imageurl = self.domSanitizer.bypassSecurityTrustUrl('data:image/jpg;base64, ' + base64String);
        console.log(data);

      // }
    })
  }

}
