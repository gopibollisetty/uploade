import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  constructor(private http:HttpClient) { }

  patientRegistration(patientRegistration): Observable<any>{
    alert("patient::service working")
    return  this.http.post("http://localhost:8090/IMCPIS/pat/save",patientRegistration);
  }

  patientRetrival():Observable<any>{
    return this.http.get("http://localhost:8090/IMCPIS/pat/get");
  }

  uploadeData(data):Observable<any>{
    return this.http.get('http://localhost:8090/IMCPIS/pat/uploade?img-data='+data);
  }


  imageRetrieval():Observable<any>{
    return this.http.get("http://localhost:8090/IMCPIS/pat/get-all-images");
  }
}
