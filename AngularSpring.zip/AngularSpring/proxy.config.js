const PROXY_CONFIG =[

    {
        
            "context":[
              "/IMCPIS"
            ],
            "target":"",
            "secure":false,
            "logLevel": "debug",
            changeOrigin:true,
            onProxyReq:(proxyReq,req,rest)=>{
                req.setTimeout(60000);
            },
            onProxyRes:(proxyRes)=>{
                proxyRes.headers['Access-Control-Allow-Origin']='*';
                proxyRes.headers['X-Frame-Options']='SAMEORIGIN';
            }
             }
];
module.exports=PROXY_CONFIG;